﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coaspharma.Dal.Model
{
    public class gnempre
    {
        public int emp_codi { get; set; }
        public string emp_nomb { get; set; }
    }
}
