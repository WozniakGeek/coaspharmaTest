﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace coaspharma.Dal.Model
{
   public class gnmaedepModel
    {
        public int dep_codi { get; set; }
        public string dep_nomb { get; set; }
    }
}
